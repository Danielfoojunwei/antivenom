# ANTIVENOM publication review candidate

PRIVATE REVIEW CANDIDATE. Not a submitted, accepted or public paper/release.

Start with paper/manuscript.md and docs/PUBLICATION_READINESS.md. The PDF is
output/pdf/antivenom_manuscript_draft.pdf. This package distinguishes completed
local evidence from the untested fresh representation claim. It contains
no native MemMorph results and no completed independent human ratings.

Rebuild evidence tables without models/network, using Python 3.12+:

    python paper/generate_tables.py

That is evidence-table regeneration, not independent scientific replication.
The exact empty-history control's generated answers are included. Full
raw contexts/checkpoints and external data/weights remain in the original
local checkout; their identities are indexed, not copied. Follow the pinned
protocols and THIRD_PARTY_NOTICES.md to obtain external inputs. Do not launch
old completed experiment queues from a review checkout. The new confirmation
study has zero fresh certified local families and no enabled inference run.

MANIFEST.json lists every archive member hash. Verify before extracting:

    python analysis/prepare_publication_release.py --verify ARCHIVE.zip

Human review: use publication_v2 in the full local checkout. Individual
reviewer sheets, private method mappings, attestations and adjudication are
excluded to protect blinding and reviewer identities. V1's adjudication
overwrite defect was found and fixed in separately preserved V2 before any
human work. Historical protocols are retained and may describe superseded
plans; the readiness index and manuscript identify the current scope.

Before public release: author review/consent, authorship/affiliations, an
explicit license for original project code, privacy/path review and third-
party redistribution review remain required. Original license texts and
notices are preserved; this archive invents no project license. Do not infer
permission or publication readiness from the existence of this ZIP.

All work before the 6-8 November 2026 hackathon sprint is preexisting work.
No public upload, submission, outreach or external compute was performed.
